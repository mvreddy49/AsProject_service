package com.wow.webapp.domain.model;

public class ClinicTestSearchModel {
	
	
	private String test_name;

	public String getTest_name() {
		return test_name;
	}

	public void setTest_name(String test_name) {
		this.test_name = test_name;
	}


}
