package com.wow.webapp.domain.model;

public class RegisterUserModel extends LoginModel {
	
	public RegisterUserModel(){
		super();
	}

}
